/*write javascript code*/
<script type="text/javascript">
	var images = ["image1.jpeg", "image2.jpeg", "image3.jpeg"];
	var i = 0;
	function changeImage() {
		document.getElementById("image").src = images[i];
		if (i < images.length - 1) {
			i++;
		} else {
			i = 0;
		}
	}
	setInterval(changeImage, 2000);
</script>

/*write html code for student.html*/
<!DOCTYPE html>
<!-- Path: student.html -->
<html>
<head>
	<title>Student</title>
	<link rel="stylesheet" type="write html, css, javascript code-->

<html>
<head>
<title>Classroom Attendance App</title>
<link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript" src="script.js"></script>
</head>
<body>
<div id="heading">
<h1>Classroom Attendance App</h1>
</div>
<div id="images">
<img id="image1" src="image1.jpeg" alt="image1" style="display:block;">
<img id="image2" src="image2.jpeg" alt="image2" style="display:none;">
<img id="image3" src="image3.jpeg" alt="image3" style="display:none;">
</div>
</body>
</html>